package com.capstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmsMsg91Application {

	public static void main(String[] args) {
		SpringApplication.run(SmsMsg91Application.class, args);
	}

}
